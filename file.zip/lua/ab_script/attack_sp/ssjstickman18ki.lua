﻿setDisp(0, 0, 0) -- Turn off player sprite
setDisp(0, 1, 0) -- Turn off enemy sprite
setVisibleUI(0, 0) -- Turn offUI
changeAnime(0, 0, 0) -- Reset player sprite to default
changeAnime(0, 1, 0) -- Reset enemy sprite to default 
setAnimeLoop(0, 0, 1) -- Loop player sprite
setAnimeLoop(0, 1, 1) -- Loop enemy sprite

Starting = 694200;
ef_001 = Starting + 38;
ef_001_bg = Starting + 39;
frameCount = 180;

background = entryEffect(0, ef_001_bg, 0x80, -1, 0, 0, 0) -- Setup background layer with 0x80
anim = entryEffect(0, ef_001, 0x100, -1, 0, 0, 0) -- Setup foreground layer

-- Controlling the enemy sprite
setDisp(76 * 2, 1, 1) -- Show enemy on frame 76
changeAnime(76 * 2, 1, 100) -- Change enemy sprite to idle front on frame 76
setMoveKey(76 * 2, 1, 70, -12, 0) -- Move enemy sprite to (70, -12) on frame 76
setScaleKey(76 * 2, 1, 10, 5) -- Scale enemy sprite by 3 times on frame 76
setRotateKey(76 * 2, 1, 0) -- Rotate enemy sprite by -70 degrees on frame 76

dealDamage(174 * 2) -- Show damage on frame 174
endPhase(frameCount * 2) -- End 
﻿-- Stick 18
-- i think this used to be the 18ki but who cares 
fcolor_r = 255;
fcolor_g = 255;
fcolor_b = 255;

SE_01 = 1049;

setDisp(0, 0, 0) -- Turn off player sprite
setDisp(0, 1, 0) -- Turn off enemy sprite
setVisibleUI(0, 0) -- Turn offUI
changeAnime(0, 0, 0) -- Reset player sprite to default
changeAnime(0, 1, 0) -- Reset enemy sprite to default 
setAnimeLoop(0, 0, 1) -- Loop player sprite
setAnimeLoop(0, 1, 1) -- Loop enemy sprite

Starting = 694200;
ef_001 = Starting + 36;
ef_001_bg = Starting + 37;
frameCount = 378;

background = entryEffect(0, ef_001_bg, 0x80, -1, 0, 0, 0) -- Setup background layer with 0x80
animation = entryEffect(0, ef_001, 0x0, -1, 0, 0, 0) -- Setup 

-- Controlling the enemy sprite
setDisp(46 * 2, 1, 1) -- Show enemy on frame 46
changeAnime(46 * 2, 1, 100) -- Change enemy sprite to idle front on frame 46
setMoveKey(46 * 2, 1, 154, -70, 0) -- Move enemy sprite to (154, -70) on frame 46
setScaleKey(46 * 2, 1, 1.0, 1.0) -- Scale enemy sprite by 3 times on frame 46
setRotateKey(46 * 2, 1, 0) -- Rotate enemy sprite by -70 degrees on frame 46


-- setDisp(61 * 2, 1, 1) -- Show enemy on frame 61
changeAnime(61 * 2, 1, 106) -- Change enemy sprite to idle front on frame 61
-- setMoveKey(61 * 2, 1, 154, -70, 0) -- Move enemy sprite to (154, -70) on frame 61
-- setScaleKey(61 * 2, 1, 1.0, 1.0) -- Scale enemy sprite by 3 times on frame 61
-- setRotateKey(61 * 2, 1, 0) -- Rotate enemy sprite by -70 degrees on frame 61

setDisp(137 * 2, 1, 0) -- Show enemy on frame 137

setDisp(325 * 2, 1, 1) -- Show enemy on frame 50
changeAnime(325 * 2, 1, 2) -- Change enemy sprite to idle front on frame 50
setMoveKey(325 * 2, 1, -233.9, -287.9, 0) -- Move enemy sprite to (250, 75) on frame 50
setScaleKey(325 * 2, 1, 1.0, 1.0) -- Scale enemy sprite by 3 times on frame 50
setRotateKey(325 * 2, 1, 0) -- Rotate enemy sprite by -70 degrees on frame 50

setDisp(348 * 2, 1, 0) -- Show enemy on frame 348
changeAnime(348 * 2, 1, 2) -- Change enemy sprite to idle front on frame 348
setMoveKey(348 * 2, 1, -233.9, -287.9, 0) -- Move enemy sprite to (-233.9, -287.9) on frame 348
setScaleKey(348 * 2, 1, 1.0, 1.0) -- Scale enemy sprite by 3 times on frame 348
setRotateKey(348 * 2, 1, 0) -- Rotate enemy sprite by -70 degrees on frame 348

dealDamage(351 * 2) -- Show damage on frame 351
endPhase(frameCount * 2) -- End
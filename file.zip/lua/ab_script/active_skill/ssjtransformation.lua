﻿setVisibleUI(0, 0); -- Hide UI
setDisp(0, 0, 0); -- Hide player sprite
setDisp(0, 1, 0); -- Hide enemy sprite
changeAnime(0,1,0);

Starting = 694200;
animationfolder = Starting + 35;
framecount = 100;

-- entryEffectLife(0, 694200, 0x80, -1, 0, 0, 0); -- Play entire animation of 694200
entryEffect(0, animationfolder, 0x01, -1, 0, 0, 0); -- Play entire animation of 694200 
-- playSeLife(0, 9000, 5)

playSe(0, 1132)
setSeVolume(0, 1132, 999999999999999999999999999999999999999999999999999999999999999999 );

endPhase(framecount * 2); -- End of animation at frame 269